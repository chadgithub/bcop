var _seconds = 0;
var isLocked = false;
var _t = 0;

$(document).ready(function(){
	$.ajax({
		url: url + "/main/seconds_to_next",
		cache: false
	}).done(function(data){
		$(".seconds").html(data);
		_t = data;
	});	

	_seconds = $(".seconds").html();

	$('.button-lock').click(function(){
		if(!$(this).hasClass('locked')){
			isLocked = true;
		}
		else{
			isLocked = false;
		}
		lock_text();
	});

	_t = parseInt($(".seconds").html());
});

var x = setInterval(function (){
	if(_t == 1){
		$.get(url + "/main/seconds_to_next", function(data){
    		_t = data;
		});
		if(isLocked) makeKey();		
	}
	$(".seconds").html(_t - 1);
	_t = parseInt($(".seconds").html());
}, 1000);

function lock_text(){
	if(isLocked){
		$('.input-password').animate({
			backgroundColor : 'rgb(146, 146, 146)',
			color: 'rgb(95, 95, 95)'
		},200);
		$('.input-password').attr("disabled", "disabled");
		$('.button-lock').attr("value", "Unlock");

		$('.button-lock').addClass("locked");

		$('.generated-value .p').css('opacity', 0).html('Waiting for next generation of key.');
		$('.generated-value .p').animate({opacity:1},300);
	}
	else if(!isLocked){
		$('.input-password').animate({
			backgroundColor : 'rgb(255, 255, 255)',
			color: 'rgb(116, 116, 116)'
		},200);
		$('.input-password').removeAttr("disabled");
		$('.button-lock').attr("value", "Lock");

		$('.button-lock').removeClass("locked");
		$('.generated-value .p').html('');
	}
}

function makeKey(){
	if(isLocked);
	var _pass = $('.input-password').val();

	$('.generated-value .p').css('opacity', 0);
	$('.generated-value .p').animate({opacity:1},300);
	$('.generated-value .p').load(url + '/main/pass/' + _pass);
}