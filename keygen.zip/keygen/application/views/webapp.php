<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="webroot/cs/theme.css">
	<script type="text/javascript">
		var url = '<?=$url?>';
	</script>
	<script type="text/javascript" src="webroot/js/jquery.min.js"></script>
	<script type="text/javascript" src="webroot/js/jquery.color.js"></script>
	<script type="text/javascript" src="webroot/js/main.js"></script>
</head>
<body>
	<div class='title'>
		Keygen
	</div>
	<div class='main'>
		<div class='upper'>
			<span class='label-password'>Passphrase:</span>
			<input type='password' class='input-password'>
			<input type='button' class='button-lock lock' value='Lock'></button>
		</div>
		<div class='lower'>
			<div class='generated-value'><div class='p'></div></div>
		</div>
		<div class='seconds-to-next'>
			Seconds to next generation: <span class='seconds'></span>
		</div>
	</div>
</body>
</html>