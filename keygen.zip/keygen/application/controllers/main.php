<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

	public $key = '';
	public $pass = '';

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('encrypt');
	}

	public function index()
	{
		$data['url'] = current_url();
		$this->load->view('webapp', $data);
	}

	public function pass($password = ''){
		$time_factor = date('U');
		$key = '';
		if(($time_factor % 10 == 0)){
			#echo $time_factor;
			$key = $password.$time_factor;
			$pass = $this->encrypt->encode('matilda',$key);
			$pass = substr_replace($pass, "<br>", 20, 0);
			$pass = substr_replace($pass, "<br>", 45, 0);
			$pass = substr_replace($pass, "<br>", 70, 0);
			if(strlen($pass) > 90) $pass = substr_replace($pass, "<br>", 95, 0);
			echo $pass.'<br>';
		}
	}

	public function seconds_to_next(){
		$time_factor = date('U');
		echo (10 - ($time_factor % 10));
	}
}